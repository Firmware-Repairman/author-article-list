# Release Notes

These are the release notes for **AuthorArticleList.php**. The format is
**v{MAJOR}.{MINOR}

# v1.2

2025-08-30

## Fixed

None

## Added

None

## Changed

- Articles in categories **Chinese** and **En Espanol** are filtered out

----

# v1.1

2025-08-27

## Fixed

None

## Added

- This file, README.md, and the php file


## Changed

