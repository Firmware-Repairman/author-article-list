# Release Notes

These are the release notes for **author-article-list.php**. The format is
**v{MAJOR}.{MINOR}


# v1.3

2025-09-07

## Fixed

None

## Added

- Radio buttons for different time ranges rather than only for the past year

## Changed

None

## Removed

None

----
----

# v1.2

2025-08-30

## Fixed

None

## Added

## Changed

None

## Removed

- Articles in the categories Chinese or En Espanol have been removed to 
eliminate redundant reporting of the same article

----
----

# v1.1

2025-08-27

## Fixed

None

## Added

- This file, README.md, and the php file


## Changed

None

## Removed

None