# AuthorArticleList

This program was written for the editors of Mission Local SF to count and
display the articles by each author over the period selected. The results are found
in the Wordpress Dashboard in the Settings menu for "list of Articles by Author".

# Installation

- Download the release you want from the releases directory. Currently 1.3 is the latest
- Or, create a zip file of this directory without the .git subdirectory

Upload the zip file to your plugins directory and activate it. A new entry will appear
in the Settings section of your dashboard 
