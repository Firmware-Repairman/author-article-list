# AuthorArticleList

This program was written for the editors of Mission Local SF to count and
display the articles by each author over the past year. The results are found
in the Wordpress Dashboard in the Settings menu for Author Article List.

# Installation

Create a zip file of this directory without the .git subdirectory and upload it
to your plugins directory
