# Release Notes

These are the release notes for **AuthorArticleList.php**. The format is
**v{MAJOR}.{MINOR}

# v1.1

2025-08-27

## Fixed

None

## Added

- This file, README.md, and the php file


## Changed

